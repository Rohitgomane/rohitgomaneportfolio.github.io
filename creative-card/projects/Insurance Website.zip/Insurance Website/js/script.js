var cont = document.querySelector(".cont");




function submit_button() {
    cont.innerHTML = "<div class='thanks'>" +
        "<img src='images/tick.gif'>" +
        "<h1>Thank You!</h1>" +
        "<a href='index.html'><button>Return to home</button>" +
    "</div>";
}



